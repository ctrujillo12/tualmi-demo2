'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Product } from '@/types';
import { useCartStore } from '@/store/cartStore';
import { PRODUCT_DETAILS, type HighlightIcon } from '@/lib/productDetails';
import { PRODUCT_COLORS, PRODUCT_COLOR_IMAGES, PRODUCT_LIFESTYLE_IMAGES, cartThumbFor } from '@/lib/productColors';
import { useShopAccess, isBuyable, GATED_HANDLES, PREORDER_HANDLES } from '@/lib/useShopAccess';
import DiscountBadge from '@/components/DiscountBadge';
import { FREE_SHIPPING_LABEL } from '@/lib/shipping';
import { shipLabel } from '@/lib/shipWindow';
import { RETURN_WINDOW_DAYS } from '@/lib/business';
import { LOW_STOCK_LABEL, SOLD_OUT_LABEL } from '@/lib/lowStock';
import { availability, isSoldOut, isColorSoldOut, maxPurchasable } from '@/lib/inventory';
import ImageLightbox from '@/components/ImageLightbox';
import { trackViewItem, trackAddToCart } from '@/lib/analytics';
import { ReviewStars, FitConsensus } from '@/components/ProductReviews';
import { modelNoteFor } from '@/lib/models';
import type { ReviewSummary } from '@/lib/reviews';

interface ProductDetailClientProps {
  product: Product;
  initialColor?: string;
  /**
   * Computed on the server and passed down rather than read here — this is a
   * client component, and there is no reason to make the browser fetch reviews
   * to render a number the server already knows.
   */
  reviews?: ReviewSummary;
}

// ─── Landing-page design tokens ───────────────────────────────────────────────
const sans    = 'var(--font-montserrat), system-ui, sans-serif';
const maroon  = '#A9445C';
const blushBg = '#FBF1F5';
const soft    = '#C9849A';
const rule    = '#F0D9E1';

/**
 * Space between the size row and the colour row, on every product page.
 *
 * One constant because it has to be identical on the shorts and the pant, and
 * because it is the number to nudge if the "color · picnic" line sits too close
 * to the size pills (raise it) or too far from them (lower it). It lives on the
 * colour block rather than the size block so it cannot be changed by whatever
 * does or does not render inside the size block on a given product.
 */
const COLOUR_BLOCK_GAP = '24px';

/**
 * Trust strip claims for a product that doesn't name its own.
 *
 * ONLY claims true of EVERY product belong here. This used to include
 * 'recycled fabric', which is true of the shorts and false of the pant — so a
 * product that forgot to set `trustClaims` silently printed a false material
 * claim. Both live products now name their own claims in lib/productDetails.ts;
 * this is the safe floor for anything new.
 */
const DEFAULT_TRUST_CLAIMS = ['women-owned', 'WRAP-certified', 'designed in LA'];

const eyebrowStyle: React.CSSProperties = {
  fontFamily: sans,
  fontWeight: 700,
  fontSize: '13px',
  letterSpacing: '0.14em',
  color: soft,
  margin: 0,
  textTransform: 'lowercase',
};

const bodyStyle: React.CSSProperties = {
  fontFamily: sans,
  fontWeight: 500,
  fontSize: '14px',
  lineHeight: 2,
  color: soft,
  margin: 0,
  textAlign: 'left',
};

// ─── Feature-highlight icons (Halfday-style strip) ────────────────────────────
function HighlightGlyph({ icon }: { icon: HighlightIcon }) {
  const common = { width: 21, height: 21, viewBox: '0 0 24 24', fill: 'none', stroke: maroon, strokeWidth: 1.5, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  switch (icon) {
    case 'moisture': // single water drop
      return <svg {...common}><path d="M12 3.5c2.8 3 5 5.6 5 8.5a5 5 0 0 1-10 0c0-2.9 2.2-5.5 5-8.5Z" /></svg>;
    case 'water': // water-resistant — drop with a slash
      return <svg {...common}><path d="M12 3.5c2.8 3 5 5.6 5 8.5a5 5 0 0 1-10 0c0-2.9 2.2-5.5 5-8.5Z" /><path d="M5.5 5.5 18.5 18.5" /></svg>;
    case 'feather': // ultra-light
      return <svg {...common}><path d="M19 5a7 7 0 0 0-9.9 0L5 9.1a5.5 5.5 0 0 0 0 7.8L19 5Z" /><path d="M5 19 12 12" /><path d="M15.5 8.5 11 13" /></svg>;
    case 'recycled': // clean circular recycle / renew loop
      return <svg {...common}><path d="M20.5 8V3.5H16" /><path d="M20.5 3.5 16.5 7.5A7 7 0 0 0 5.2 9.6" /><path d="M3.5 16v4.5H8" /><path d="M3.5 20.5 7.5 16.5A7 7 0 0 0 18.8 14.4" /></svg>;
    case 'uv': // sun
      return <svg {...common}><circle cx="12" cy="12" r="3.8" /><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.2 5.2l1.6 1.6M17.2 17.2l1.6 1.6M18.8 5.2l-1.6 1.6M6.8 17.2l-1.6 1.6" /></svg>;
    case 'pocket': // pocket
      return <svg {...common}><rect x="4.5" y="4.5" width="15" height="15" rx="2.5" /><path d="M8.5 4.5v3a3.5 3.5 0 0 0 7 0v-3" /></svg>;
    case 'stretch': // expand both ways
      return <svg {...common}><path d="M3.5 12h17" /><path d="M7 8.5 3.5 12 7 15.5" /><path d="M17 8.5 20.5 12 17 15.5" /></svg>;
    case 'fit': // flared-leg pant silhouette -- the cut itself, not a gender symbol
      return <svg {...common}><path d="M7.4 4.5h9.2l.4 5H7Z" /><path d="M7 9.5c-.6 4-1.3 7.2-2.2 10h3.6c.9-3.5 1.9-6.4 3.6-8.2 1.7 1.8 2.7 4.7 3.6 8.2h3.6c-.9-2.8-1.6-6-2.2-10" /></svg>;
    case 'waist': // foldover waistband — band with the fold curving over its top
      return <svg {...common}><path d="M4.5 6h15v6h-15Z" /><path d="M4.5 12c.5 3 .7 5.4.6 7.5M19.5 12c-.5 3-.7 5.4-.6 7.5" /><path d="M4.5 6c2.5 1.6 12.5 1.6 15 0" /></svg>;
    case 'cinch': // cinched hem / drawstring
      return <svg {...common}><path d="M8 4v6M16 4v6" /><path d="M8 10c1.3 1.3 2.5 1.3 4 1.3s2.7 0 4-1.3" /><path d="M9.5 11.2 8 20M14.5 11.2 16 20" /></svg>;
    default:
      return null;
  }
}

export default function ProductDetailClient({ product, initialColor, reviews }: ProductDetailClientProps) {
  const handle       = product.handle ?? '';
  const { canShop, ready } = useShopAccess();
  const isPreorder = PREORDER_HANDLES.includes(handle);
  const isGated    = GATED_HANDLES.includes(handle);
  const buyable    = isBuyable(handle, canShop);   // sellable AND shop open (if gated)
  const lockedForLaunch = isGated && !canShop;     // sellable but shop not open yet

  // Shopify's custom.shipping_window metafield wins wherever it is set; the
  // fallbacks below cover it being empty or missing.
  //
  // The in-stock branch used to be the literal 'In stock, ships in 1–2
  // business days'. Three places stated the handling time and they said 1–2
  // here, 1–3 in the structured data and 2–3 on the shipping page — the same
  // drift that put a dead preorder date on four pages. 1–3 is now the standing
  // claim and it matches what the feed tells Google.
  const shippingLabel = isPreorder
    ? (product.shippingWindow || shipLabel())
    : buyable
      ? (product.shippingWindow || shipLabel())
      : (product.shippingWindow ?? 'Coming soon');

  const addItem = useCartStore((state) => state.addItem);
  const updateQuantity = useCartStore((state) => state.updateQuantity);

  const swatchColors = PRODUCT_COLORS[handle] ?? [];
  const colorImageMap = PRODUCT_COLOR_IMAGES[handle];
  const colorCount   = Math.max(1, swatchColors.length || product.colors.length);
  const imgsPerColor = Math.max(1, Math.floor(product.images.length / colorCount));

  const getColorImages = (colorIdx: number): string[] => {
    // Prefer an explicit per-color image list (handles uneven photo counts)
    const colorName = swatchColors[colorIdx]?.name ?? product.colors[colorIdx];
    if (colorImageMap && colorName && colorImageMap[colorName]?.length) {
      return colorImageMap[colorName];
    }
    // Fallback: split product.images evenly across colors
    const start = colorIdx * imgsPerColor;
    const end   = colorIdx === colorCount - 1 ? product.images.length : start + imgsPerColor;
    return product.images.slice(start, end);
  };

  const [focusIdx, setFocusIdx]           = useState(0); // mobile hero photo
  // Deliberately NO default size. Pre-selecting the first option (2XS) meant
  // people could add to cart without ever choosing, and only discover the
  // wrong size on delivery. One-size products are the exception — there's
  // nothing to choose.
  const [selectedSize, setSelectedSize] = useState(
    product.sizes.length === 1 ? product.sizes[0] : ''
  );
  const [selectedColor, setSelectedColor] = useState(() => {
    const fallback = swatchColors.length > 0 ? swatchColors[0].name : (product.colors[0] || '');
    // Case-insensitive so shared links work whether they say Confetti or confetti.
    if (initialColor) {
      const match = swatchColors.find(
        (s) => s.name.toLowerCase() === initialColor.trim().toLowerCase()
      );
      if (match) return match.name;
    }
    return fallback;
  });
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  // Only tracks failures now — the "added" state is derived from the cart
  // itself (see cartQty), so the button can't disagree with what's in the cart.
  const [buyStatus, setBuyStatus] = useState<'idle' | 'added' | 'error'>('idle');

  const fabricDetail = PRODUCT_DETAILS[handle] ?? null;

  const handleColorSelect = (color: string) => {
    setSelectedColor(color);
    setFocusIdx(0);
    // The outdoor set differs per colourway and isn't the same length, so a
    // stale index here would open the viewer on the wrong photo or on nothing.
    setLifestyleIdx(null);
    // Persist the choice in the URL so a refresh keeps the same colorway
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('color', color);
      window.history.replaceState(null, '', url.toString());
    }
  };

  const handleAddToCart = () => {
    try {
      const colorIdx = swatchColors.length > 0
        ? swatchColors.findIndex((s) => s.name === selectedColor)
        : product.colors.indexOf(selectedColor);
      const colorImages = getColorImages(Math.max(0, colorIdx));

      // Cart image, colour-scoped at every step. Shopify's image for THIS
      // colourway wins (so re-uploading the shoot to Shopify updates the cart),
      // then the local gallery for the same colourway. The old chain ended in
      // `product.images.find(u => u.startsWith('http'))` — the product's first
      // Shopify image regardless of colour — which is how a Picnic line could
      // end up showing a Jam photo.
      const cartImg = cartThumbFor(handle, selectedColor, product.variants) ?? colorImages[0];

      // Items with a future ship window (e.g. the pant's preorder week)
      // are flagged as preorder so the date carries onto the Shopify order.
      const shipWindow = product.shippingWindow ?? '';
      const shipsLater = !!shipWindow && !shipWindow.toLowerCase().startsWith('in stock');
      addItem(
        { ...product, images: cartImg ? [cartImg] : colorImages },
        selectedSize, selectedColor, 1,
        { isPreorder: shipsLater, shippingWindow: shipsLater ? shipWindow : undefined },
      );
      trackAddToCart({
        item_id: handle,
        item_name: product.name,
        price: product.price / 100,
        item_variant: `${selectedColor} / ${selectedSize}`,
        quantity: 1,
        image_url: cartImg,
        url: `/products/${handle}?color=${encodeURIComponent(selectedColor)}`,
      });
      setBuyStatus('added');
    } catch (e) {
      console.error('[addToCart] failed:', e);
      setBuyStatus('error');
    }
  };

  const toggleSection = (section: string) =>
    setExpandedSection(expandedSection === section ? null : section);

  /**
   * How many of THIS exact size+colour are already in the cart. Drives the
   * +/- stepper below, so the control always reflects real cart state — if the
   * shopper switches size or colour, the stepper resets to "add to cart"
   * because that's a different line item.
   */
  const cartQty = useCartStore(
    (state) =>
      state.items.find(
        (i) =>
          i.product.id === product.id &&
          i.selectedSize === selectedSize &&
          i.selectedColor === selectedColor
      )?.quantity ?? 0
  );

  const setQty = (next: number) =>
    updateQuantity(product.id, selectedSize, selectedColor, next);

  /**
   * Ceiling on the quantity stepper: 10, or whatever Shopify actually has,
   * whichever is smaller. When stock isn't readable the cap stays at 10 and
   * Shopify enforces the truth at payment.
   */
  const MAX_QTY = maxPurchasable(product, selectedColor, selectedSize, 10);

  /** Live availability of exactly what's selected right now. */
  const selected = availability(product, selectedColor, selectedSize);
  const selectedSoldOut = selected.status === 'sold-out';

  /**
   * A size that's fine in Jam may be gone in Picnic. Switching colourway can
   * therefore strand the shopper on a selection that no longer exists — so
   * clear it and make them pick again, rather than letting them tap buy on
   * something we already know can't be sold.
   */
  useEffect(() => {
    if (selectedSize && isSoldOut(product, selectedColor, selectedSize)) {
      setSelectedSize('');
    }
  }, [selectedColor, selectedSize, product]);

  // ── Sticky mobile buy bar ──────────────────────────────────────────────────
  // 95.6% of traffic is mobile and 93.8% of product viewers never add to cart.
  // Tap any gallery photo to open it full-screen with zoom.
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  /**
   * Outdoor shots for the selected colourway, shown as a small row under the
   * description rather than inside the gallery — see the note on
   * PRODUCT_LIFESTYLE_IMAGES. Empty for products that don't have any, in which
   * case the whole section doesn't render.
   */
  const lifestyleImages = PRODUCT_LIFESTYLE_IMAGES[handle]?.[selectedColor] ?? [];
  const [lifestyleIdx, setLifestyleIdx] = useState<number | null>(null);

  const sizeRef = useRef<HTMLDivElement>(null);
  const inlineCtaRef = useRef<HTMLDivElement>(null);
  const [flashSize, setFlashSize] = useState(false);

  /**
   * Visibility of the sticky bar.
   *
   * This was `window.scrollY > 320` with an initial state of `false` — a
   * fail-HIDDEN design. In practice the bar never appeared at all: it computed
   * to opacity 0 / pointer-events none at every scroll position, so on a store
   * where 95%+ of traffic is mobile the most valuable CTA on the page was
   * invisible and un-tappable.
   *
   * Inverted to fail-VISIBLE. The bar starts on, and the only thing that hides
   * it is the inline buy box actually being on screen, where it would be
   * redundant. If the observer never fires — old browser, blocked API, a
   * layout it can't resolve — the shopper still gets a live CTA.
   */
  const [showStickyBar, setShowStickyBar] = useState(true);

  useEffect(() => {
    const el = inlineCtaRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      setShowStickyBar(true);
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => setShowStickyBar(!entry.isIntersecting),
      // A sliver of the buy box counts as "on screen"; the bottom margin stops
      // the bar flickering as the box slides underneath it.
      { threshold: 0.35, rootMargin: '0px 0px -96px 0px' },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [buyable]);

  /**
   * Primary buy action. If no size is chosen we don't dead-end the tap —
   * scroll the picker into view and flash it, so the button always does
   * something rather than sitting inert.
   */
  const handleBuy = () => {
    if (!selectedSize) {
      sizeRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setFlashSize(true);
      window.setTimeout(() => setFlashSize(false), 1600);
      return;
    }
    // Belt and braces. The picker won't let a sold-out size be selected, but
    // the sticky bar can be tapped from anywhere on the page and stock can
    // change under a tab that's been open a while.
    if (isSoldOut(product, selectedColor, selectedSize)) {
      sizeRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setFlashSize(true);
      window.setTimeout(() => setFlashSize(false), 1600);
      return;
    }
    handleAddToCart();
  };

  // GA4 view_item + Klaviyo Viewed Product — once per product, not on every
  // colour/size change. The image and URL are Klaviyo's: they're what a
  // browse-abandon email shows, and an email with no photo doesn't convert.
  useEffect(() => {
    trackViewItem({
      item_id: handle,
      item_name: product.name,
      price: product.price / 100,
      image_url: product.images[0],
      url: `/products/${handle}`,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handle]);

  // ── Accordion content ──
  const accordionItems: { key: string; label: string; content: React.ReactNode }[] = [];

  // First in the accordion, above the spec list. These are the questions that
  // decide whether someone buys; the spec list is reference material they open
  // afterwards, if at all.
  if (fabricDetail?.faq && fabricDetail.faq.length > 0) {
    accordionItems.push({
      key: 'faq',
      label: 'questions we get',
      content: (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          {fabricDetail.faq.map((item) => (
            <div key={item.q}>
              <p style={{ margin: 0, fontWeight: 700, color: maroon }}>{item.q}</p>
              <p style={{ margin: '3px 0 0', opacity: 0.85 }}>{item.a}</p>
            </div>
          ))}
        </div>
      ),
    });
  }

  if (fabricDetail) {
    accordionItems.push({
      key: 'material',
      label: 'the technical stuff',
      content: (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <p style={{ margin: 0, opacity: 0.85 }}>For the gear nerds, here&apos;s exactly what you&apos;re getting.</p>
          <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', rowGap: '6px', columnGap: '12px' }}>
            <span style={{ color: soft, opacity: 0.8 }}>Fabric</span>
            <span>{fabricDetail.shell}</span>
            {fabricDetail.lining && (<><span style={{ color: soft, opacity: 0.8 }}>Lining</span><span>{fabricDetail.lining}</span></>)}
            {fabricDetail.pocketLining && (<><span style={{ color: soft, opacity: 0.8 }}>Pocket lining</span><span>{fabricDetail.pocketLining}</span></>)}
            {fabricDetail.weight && (<><span style={{ color: soft, opacity: 0.8 }}>Weight</span><span>{fabricDetail.weight}</span></>)}
          </div>
          {fabricDetail.features && fabricDetail.features.length > 0 && (
            <ul style={{ margin: '2px 0 0', padding: '0 0 0 14px', display: 'flex', flexDirection: 'column', gap: '5px' }}>
              {fabricDetail.features.map((f, i) => <li key={i}>{f}</li>)}
            </ul>
          )}
        </div>
      ),
    });
  }

  if (fabricDetail?.tempGuide) {
    accordionItems.push({
      key: 'temp',
      label: 'temperature guide',
      content: (
        <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr', rowGap: '8px', columnGap: '12px' }}>
          <span style={{ color: soft, opacity: 0.8 }}>Standalone ideal for</span>
          <span>{fabricDetail.tempGuide.standalone}</span>
          <span style={{ color: soft, opacity: 0.8 }}>Layered use</span>
          <span>{fabricDetail.tempGuide.layered}</span>
        </div>
      ),
    });
  }

  accordionItems.push({
    key: 'care',
    label: 'care',
    content: (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
        {(fabricDetail?.care ?? ['Machine wash cold', 'Hang dry', 'Do not bleach', 'Do not iron'])
          .map((line, i) => <p key={i} style={{ margin: 0 }}>{line}</p>)}
      </div>
    ),
  });

  if (fabricDetail?.sizeChart) {
    const chart = fabricDetail.sizeChart;
    accordionItems.push({
      key: 'sizeguide',
      label: 'size guide',
      content: (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '480px' }}>
            <thead>
              <tr>
                <th style={{ padding: '6px 8px 8px 0', borderBottom: `1.5px solid ${maroon}` }}> </th>
                {chart.sizes.map((s) => (
                  <th key={s} style={{ padding: '6px 4px 8px', textAlign: 'center', fontFamily: sans, fontSize: '12px', fontWeight: 700, color: maroon, textTransform: 'lowercase', borderBottom: `1.5px solid ${maroon}` }}>
                    {s}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {chart.rows.map((row) => (
                <tr key={row.label} style={{ borderBottom: `1px solid ${rule}` }}>
                  <td style={{ padding: '7px 8px 7px 0', fontFamily: sans, fontSize: '13px', fontWeight: 500, color: soft, whiteSpace: 'nowrap' }}>{row.label}</td>
                  {row.values.map((v, j) => (
                    <td key={j} style={{ padding: '7px 4px', textAlign: 'center', fontFamily: sans, fontSize: '13px', fontWeight: 500, color: soft }}>{v}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          {chart.note && (
            <p style={{ ...bodyStyle, fontSize: '12px', margin: '8px 0 0' }}>{chart.note}</p>
          )}
        </div>
      ),
    });
  }

  accordionItems.push({
    key: 'shipping',
    label: 'shipping & returns',
    content: (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
        <p style={{ margin: 0 }}>{RETURN_WINDOW_DAYS}-day returns and exchanges</p>
        {shippingLabel && <p style={{ margin: 0 }}>{shippingLabel}.</p>}
      </div>
    ),
  });

  const activeColorIdx = swatchColors.length > 0
    ? swatchColors.findIndex((s) => s.name === selectedColor)
    : product.colors.indexOf(selectedColor);
  const gallery     = getColorImages(Math.max(0, activeColorIdx));

  // Who is wearing what. Derived per photograph in lib/models.ts, but shown as
  // a single line in the fit block rather than stamped on every image.
  const productHandle = product.handle ?? product.id;
  const modelLine = modelNoteFor(productHandle, selectedColor, gallery);

  /**
   * Mobile carousel position.
   *
   * Read OUT of the scroll container rather than driving it: the track is a
   * native scroll-snap element, so the finger is the source of truth and React
   * only follows. Stepping by the measured slide width means the 92vw in the
   * stylesheet is not duplicated here and cannot drift from it.
   */
  const swipeRef = useRef<HTMLDivElement | null>(null);
  const slideStep = () => {
    const el = swipeRef.current;
    const first = el?.firstElementChild as HTMLElement | null;
    if (!el || !first) return 0;
    return first.getBoundingClientRect().width + 8; // + gap, see .pdp-swipe
  };
  const onSwipeScroll = () => {
    const el = swipeRef.current;
    const step = slideStep();
    if (!el || step <= 0) return;
    const i = Math.round(el.scrollLeft / step);
    setFocusIdx(Math.min(gallery.length - 1, Math.max(0, i)));
  };
  const scrollToSlide = (i: number) => {
    const el = swipeRef.current;
    const step = slideStep();
    if (!el || step <= 0) return;
    el.scrollTo({ left: i * step, behavior: 'smooth' });
  };

  // A colourway change swaps the whole gallery. Without this the track stays
  // where it was and the dots claim "photo 7" over a set that now has six.
  useEffect(() => {
    setFocusIdx(0);
    swipeRef.current?.scrollTo({ left: 0 });
  }, [selectedColor]);

  return (
    <div className="pdp-page" style={{ minHeight: '100vh', backgroundColor: blushBg }}>
      <div className="pdp-shell" style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div className="pdp-layout">

          {/* ── Left: gallery ──
              `display: contents` on mobile (see globals.css) so the hero photo
              and the supporting shots become siblings of the buy box and can be
              re-ordered around it. On desktop this is just the left column. */}
          <div className="pdp-col-gallery">
            {/* Desktop: uniform 2-up grid */}
            <div className="pdp-gallery">
              {gallery.map((image, i) => (
                <div
                  key={image}
                  className="pdp-tile pdp-tile--zoom"
                  onClick={() => setLightboxIdx(i)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && setLightboxIdx(i)}
                  aria-label="View photo full screen"
                >
                  <Image
                    src={image}
                    alt={`${product.name} — ${selectedColor} ${i + 1}`}
                    fill
                    // The first tile is the LCP element on desktop. Without
                    // priority it's lazy-loaded, so the browser doesn't even
                    // request it until after layout — that's the few seconds of
                    // blank white box. The rest stay lazy.
                    priority={i === 0}
                    quality={82}
                    sizes="(max-width: 1024px) 50vw, 30vw"
                    // contain, not cover: the tile is 2/3 to match the shoot,
                    // so nothing is letterboxed — but if a future photo has a
                    // different ratio it will be shown whole on blush rather
                    // than silently cropped.
                    style={{ objectFit: 'contain' }}
                  />
                </div>
              ))}
            </div>

            {/* ── Mobile: one full-bleed swipe carousel ─────────────────
                This was three separate ways of looking at the same photographs:
                a ratio-locked hero inset on blush, a thumbnail strip under it,
                and two more shots stranded in a narrow centred column below the
                buy box. The hero read as a card floating in a frame rather than
                a photo, and the pair underneath started at a different left edge
                from everything around them.

                Now every photo lives in one horizontal snap-scrolling track
                running edge to edge, out past the shell's padding. Slides are
                92vw, so the next one always peeks at the right edge — that
                sliver IS the swipe affordance, which is why there are no
                arrows. Tapping any slide opens the existing lightbox, where
                double-tap, the zoom button and native pinch all work.

                Desktop is untouched: .pdp-gallery still renders the 2-up grid
                and this whole block is display:none above 767px. */}
            <div className="pdp-m-lead">
              <div
                className="pdp-swipe"
                ref={swipeRef}
                onScroll={onSwipeScroll}
                aria-roledescription="carousel"
                aria-label={`${product.name} photos`}
              >
                {gallery.map((image, i) => (
                  <figure
                    key={image}
                    className="pdp-swipe-slide"
                    onClick={() => setLightboxIdx(i)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => e.key === 'Enter' && setLightboxIdx(i)}
                    aria-label={`Photo ${i + 1} of ${gallery.length} — open to zoom`}
                  >
                    <Image
                      src={image}
                      alt={`${product.name} — ${selectedColor} ${i + 1}`}
                      fill
                      // The first slide is the mobile LCP. The rest are lazy:
                      // they are off-screen in the track until swiped to.
                      priority={i === 0}
                      quality={82}
                      sizes="92vw"
                      // contain on a white slide: the shoot is 2:3 and so is
                      // the box, so nothing letterboxes — and if a future photo
                      // is a different ratio it is shown whole against white
                      // rather than silently cropped.
                      style={{ objectFit: 'contain' }}
                    />
                  </figure>
                ))}
              </div>

              {gallery.length > 1 && (
                <div className="pdp-swipe-dots">
                  {gallery.map((image, i) => (
                    <button
                      key={image}
                      className={i === focusIdx ? 'active' : ''}
                      onClick={() => scrollToSlide(i)}
                      aria-label={`Photo ${i + 1} of ${gallery.length}`}
                      aria-current={i === focusIdx}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── Right: details ── */}
          <div className="pdp-col-info">

            {/* ── Buy box ──
                Everything needed to make the decision, in one block: name,
                price, size, colour, CTA. */}
            <div className="pdp-buybox" ref={inlineCtaRef}>

            {/* Trust strip. Most cold traffic lands straight on a product page
                and never sees the homepage story, so the credibility signals
                have to live here too — above the name, where they read as a
                header for the product rather than as a second footnote row
                stacked under the shipping/returns line. */}
            <div className="pdp-strip pdp-strip--trust">
              {(fabricDetail?.trustClaims ?? DEFAULT_TRUST_CLAIMS).map((claim, i) => (
                <span key={claim} className="pdp-strip-item">
                  {i > 0 && <span className="pdp-strip-sep">·</span>}
                  <span className="pdp-strip-mark">✦</span>
                  {claim}
                </span>
              ))}
            </div>

            {ready && (
              <p style={{ ...eyebrowStyle, marginBottom: '8px' }}>
                {/* Was 'available now' for anything in stock, which is the
                    one thing a shopper already assumes and tells them nothing
                    about WHEN it arrives. The ship window is the useful fact,
                    and it self-expires into a standing handling-time line. */}
                {lockedForLaunch
                  ? 'opens friday · 11am pt'
                  : shippingLabel.toLowerCase()}
              </p>
            )}

            <h1
              className="pdp-title"
              style={{
                fontFamily: sans,
                fontWeight: 700,
                fontSize: 'clamp(26px, 3.5vw, 42px)',
                letterSpacing: '-0.03em',
                color: maroon,
                margin: '0 0 6px',
                lineHeight: 1.1,
                textTransform: 'lowercase',
              }}
            >
              {product.name}
            </h1>

            {/* Price, at the size of a price. It was set in 14px body type,
                which is smaller than the nav — on a phone it read as a caption
                rather than the number the whole page exists to communicate. */}
            <p
              className="pdp-price"
              style={{
                fontFamily: sans,
                fontWeight: 700,
                fontSize: '20px',
                lineHeight: 1.2,
                color: maroon,
                margin: '0 0 18px',
              }}
            >
              ${(product.price / 100).toFixed(2)}
            </p>

            {/* The promise, directly under the price — the one place a shopper
                is actually asking "is this worth it?". Everything else in this
                column is a spec; this is the reason. See `tagline` in
                lib/productDetails.ts for why it moved up here. */}
            {fabricDetail?.tagline && (
              <p
                style={{
                  fontFamily: sans,
                  fontWeight: 600,
                  fontSize: '15px',
                  lineHeight: 1.45,
                  color: maroon,
                  margin: '-8px 0 18px',
                }}
              >
                {fabricDetail.tagline}
              </p>
            )}

            {/* Insertion A — the highest-leverage piece of the review feature.
                Everyone who lands sees this; only people who scroll reach the
                reviews themselves. Anchors to #reviews further down. Renders
                nothing until there are enough reviews to average honestly. */}
            {reviews && <ReviewStars summary={reviews} />}

            {/* Feature highlights — Halfday-style icon strip. Sits here on
                desktop, where there's room beside the gallery. On mobile the
                buy box is a flex column and this gets `order: 1` (see
                globals.css), which drops it below the CTA so it isn't standing
                between the price and the size picker at the fold. */}
            {fabricDetail?.highlights && fabricDetail.highlights.length > 0 && (
              <div
                className="pdp-highlights"
                /* ONE ROW, ALWAYS. This was flexWrap:'wrap' over fixed 56px
                   chips at width:fit-content, which held five chips on a line
                   and broke the moment a sixth was added — the strip wrapped
                   into a ragged 5+1. The phone rules below already forced a
                   single row; desktop now does the same thing, so the count of
                   chips can change without the layout deciding to have an
                   opinion about it. */
                style={{
                  display: 'flex',
                  flexWrap: 'nowrap',
                  justifyContent: 'space-between',
                  gap: '8px',
                  padding: '14px 12px',
                  marginBottom: '24px',
                  backgroundColor: 'white',
                  borderRadius: '12px',
                  width: '100%',
                  maxWidth: '100%',
                }}
              >
                {fabricDetail.highlights.map((h) => (
                  <div key={h.label} className="pdp-hl" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px', flex: '1 1 0', minWidth: 0, textAlign: 'center' }}>
                    <HighlightGlyph icon={h.icon} />
                    <span style={{ fontFamily: sans, fontSize: '9.5px', fontWeight: 600, color: maroon, lineHeight: 1.2, textTransform: 'lowercase' }}>
                      {h.label}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Sizes */}
            {product.sizes.length > 0 && product.sizes[0] !== 'One Size' && (
              <div
                ref={sizeRef}
                style={{
                  // No bottom margin on purpose — the gap to the colour block
                  // is owned by the colour block itself (COLOUR_BLOCK_GAP
                  // below). It used to live here, which made it depend on
                  // whether the low-stock warning inside this div happened to
                  // render: present on one product, absent on another, so the
                  // shorts and the pant did not match.
                  marginBottom: 0,
                  // Flashes when someone taps buy without choosing a size.
                  borderRadius: '12px',
                  padding: flashSize ? '10px' : 0,
                  // Cancels the 10px padding above exactly, on every side.
                  margin: flashSize ? '-10px' : undefined,
                  backgroundColor: flashSize ? '#FBF1F5' : 'transparent',
                  boxShadow: flashSize ? `0 0 0 2px ${maroon}` : 'none',
                  transition: 'background-color 0.3s ease, box-shadow 0.3s ease',
                }}
              >
                <p style={{ ...eyebrowStyle, fontSize: '12px', marginBottom: '10px' }}>size</p>
                <div className="pdp-sizes">
                  {product.sizes.map((size) => {
                    // Real Shopify availability for this exact size + colourway.
                    // An unknown answer (Shopify down, size not a variant) reads
                    // as available — see lib/inventory.ts.
                    const state = availability(product, selectedColor, size);
                    const soldOut = state.status === 'sold-out';
                    const low = state.low;
                    return (
                      <button
                        key={size}
                        onClick={() => !soldOut && setSelectedSize(size)}
                        disabled={soldOut}
                        // Announced rather than left to the dot or the
                        // strikethrough alone — neither means anything to a
                        // screen reader.
                        aria-label={
                          soldOut ? `${size} — ${SOLD_OUT_LABEL}`
                          : low ? `${size} — ${LOW_STOCK_LABEL}`
                          : size
                        }
                        style={{
                          position: 'relative',
                          // 42px min height: an 8px-padded 12px pill is a ~30px
                          // tap target, well under the 44px thumb minimum, and
                          // this is a phone-first store.
                          padding: '11px 18px',
                          minHeight: '42px',
                          fontFamily: sans,
                          fontSize: '12px',
                          fontWeight: 600,
                          borderRadius: '100px',
                          border: `1.5px solid ${soldOut ? rule : maroon}`,
                          backgroundColor: selectedSize === size && !soldOut ? maroon : 'transparent',
                          // Sold-out sizes stay on the page rather than
                          // disappearing: a shopper who can't find their size
                          // assumes the site is broken, where a struck-through
                          // pill tells them it exists and is gone.
                          color: soldOut ? soft : selectedSize === size ? 'white' : maroon,
                          textDecoration: soldOut ? 'line-through' : 'none',
                          opacity: soldOut ? 0.55 : 1,
                          cursor: soldOut ? 'not-allowed' : 'pointer',
                          transition: 'all 0.15s',
                        }}
                      >
                        {size}
                        {low && !soldOut && (
                          <span
                            aria-hidden
                            style={{
                              position: 'absolute',
                              top: '4px',
                              right: '5px',
                              width: '7px',
                              height: '7px',
                              borderRadius: '50%',
                              backgroundColor: '#D2402F',
                              // Ring in the pill's own background so the dot
                              // stays visible once the pill fills in maroon.
                              boxShadow: `0 0 0 1.5px ${
                                selectedSize === size ? maroon : blushBg
                              }`,
                            }}
                          />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Only once they've actually picked the low size — a warning
                    about a size nobody chose is just noise on the page. */}
                {selected.low && (
                  <p
                    role="status"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '7px',
                      fontFamily: sans,
                      fontSize: '12.5px',
                      fontWeight: 700,
                      color: '#B3341F',
                      margin: '11px 0 0',
                      textTransform: 'lowercase',
                    }}
                  >
                    <span
                      aria-hidden
                      style={{
                        width: '7px',
                        height: '7px',
                        borderRadius: '50%',
                        backgroundColor: '#D2402F',
                        flexShrink: 0,
                      }}
                    />
                    {/* A real count when Shopify will give us one — "only 3
                        left" is both more useful and more honest than a vague
                        nudge, and it's a claim we can actually stand behind. */}
                    {selected.quantity !== null && selected.quantity > 0
                      ? `only ${selected.quantity} left in ${selectedSize}`
                      : `${LOW_STOCK_LABEL} in ${selectedSize}`}
                  </p>
                )}
              </div>
            )}

            {/* Colors. The model-reference note used to sit here, between the
                size row and the swatches — two lines of italic text pushing the
                CTA further down. It now lives with fit & sizing, where someone
                actually looking for it will go. */}
            {swatchColors.length > 0 && (
              <div style={{ marginTop: COLOUR_BLOCK_GAP, marginBottom: '16px' }}>
                {/* 12px under the label, not 8: it needs to read as the heading
                    for the dots below it rather than as a caption hanging off
                    the size row above. */}
                <p style={{ ...eyebrowStyle, fontSize: '12px', marginBottom: '12px' }}>
                  color · {selectedColor.toLowerCase()}
                </p>
                {/* gap 0: each button is a 42px tap target around a 26px dot,
                    so the dots already sit 16px apart — adding gap on top of
                    that spread them across half the column. */}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 0, marginLeft: '-8px' }}>
                  {swatchColors.map((swatch) => {
                    const isSelected = selectedColor === swatch.name;
                    const isGradient = swatch.value.startsWith('linear-gradient');
                    // Only when EVERY size in the colourway is confirmed gone.
                    // Still selectable — the shopper should be able to look at
                    // it, and the size row then explains itself.
                    const colorGone = isColorSoldOut(product, swatch.name);
                    return (
                      <button
                        key={swatch.name}
                        title={colorGone ? `${swatch.name} — ${SOLD_OUT_LABEL}` : swatch.name}
                        aria-label={colorGone ? `${swatch.name} — ${SOLD_OUT_LABEL}` : swatch.name}
                        aria-pressed={isSelected}
                        onClick={() => handleColorSelect(swatch.name)}
                        style={{
                          // The visible dot stays 26px; the button around it is
                          // 42px so it's a real thumb target on a phone.
                          position: 'relative',
                          width: '42px',
                          height: '42px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: 'none',
                          background: 'none',
                          cursor: 'pointer',
                          padding: 0,
                          flexShrink: 0,
                        }}
                      >
                        <span
                          aria-hidden
                          style={{
                            display: 'block',
                            width: '26px',
                            height: '26px',
                            borderRadius: '50%',
                            border: isSelected ? `2px solid ${maroon}` : '2px solid transparent',
                            outline: isSelected ? 'none' : `1px solid ${rule}`,
                            outlineOffset: '1px',
                            background: isGradient ? swatch.value : undefined,
                            backgroundColor: isGradient ? undefined : swatch.value,
                            transition: 'border-color 0.15s, transform 0.15s',
                            transform: isSelected ? 'scale(1.15)' : 'scale(1)',
                            // Faded and struck through, so a sold-out colourway
                            // reads as gone at a glance rather than only after
                            // tapping it and finding no sizes left.
                            opacity: colorGone ? 0.35 : 1,
                          }}
                        />
                        {colorGone && (
                          <span
                            aria-hidden
                            style={{
                              position: 'absolute',
                              width: '30px',
                              height: '1.5px',
                              backgroundColor: soft,
                              transform: 'rotate(-45deg)',
                              pointerEvents: 'none',
                            }}
                          />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Ship-date / delay note */}
            {fabricDetail?.shipNote && (
              <div
                style={{
                  marginBottom: '20px',
                  padding: '12px 16px',
                  borderRadius: '12px',
                  backgroundColor: 'white',
                  border: `1px solid ${rule}`,
                }}
              >
                <p style={{ ...bodyStyle, fontSize: '13px', lineHeight: 1.6, color: maroon, fontWeight: 500 }}>
                  ✦ {fabricDetail.shipNote}
                </p>
              </div>
            )}

            {/* CTA */}
            <div style={{ marginBottom: '36px' }}>
              {/* Only renders when a creator code is stored — see lib/discount.ts */}
              <DiscountBadge />

              {/* The preorder callout that sat here is gone. It read
                  "✦ preorder — {window}. you're charged today and we ship the
                  moment it lands." Nothing is sold as a preorder now, and the
                  ship window it carried is already stated in the eyebrow above
                  the title and in the shipping accordion, so removing it costs
                  no information. */}
              {buyable ? (
                /* ── Buyable: add to cart ── */
                <>
                  {/* Sold out is its own state, not a disabled add-to-cart.
                      A greyed button with a price on it reads as a bug; this
                      says what happened and offers the one thing left to do. */}
                  {selectedSoldOut ? (
                    <div>
                      <p
                        role="status"
                        style={{
                          display: 'block',
                          width: '100%',
                          boxSizing: 'border-box',
                          backgroundColor: 'white',
                          border: `1.5px solid ${rule}`,
                          color: soft,
                          padding: '16px 28px',
                          margin: 0,
                          textAlign: 'center',
                          fontFamily: sans,
                          fontSize: '15px',
                          fontWeight: 700,
                          textTransform: 'lowercase',
                          borderRadius: '100px',
                        }}
                      >
                        {SOLD_OUT_LABEL} in {selectedSize}
                      </p>
                      <p style={{ ...bodyStyle, fontSize: '12.5px', textAlign: 'center', marginTop: '10px' }}>
                        pick another size above — the rest are ready to ship.
                      </p>
                    </div>
                  ) : cartQty === 0 ? (
                    <button
                      onClick={handleBuy}
                      style={{
                        display: 'block',
                        width: '100%',
                        boxSizing: 'border-box',
                        backgroundColor: maroon,
                        cursor: 'pointer',
                        color: 'white',
                        padding: '16px 28px',
                        fontFamily: sans,
                        fontSize: '15px',
                        fontWeight: 700,
                        letterSpacing: '0.02em',
                        textTransform: 'lowercase',
                        border: 'none',
                        borderRadius: '100px',
                        transition: 'opacity 0.2s',
                      }}
                      onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.88'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.opacity = '1'; }}
                    >
                      {/* Always a real, live CTA with the price in it. Tapping
                          without a size opens the picker instead of doing
                          nothing — a dead button reads as a broken page. */}
                      {isPreorder ? 'preorder' : 'add to cart'} — ${(product.price / 100).toFixed(2)}
                    </button>
                  ) : (
                    /* ── In the cart: quantity stepper ── */
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '12px',
                        width: '100%',
                        boxSizing: 'border-box',
                        border: `1.5px solid ${maroon}`,
                        borderRadius: '100px',
                        padding: '6px 8px',
                        backgroundColor: 'white',
                      }}
                    >
                      <button
                        onClick={() => setQty(cartQty - 1)}
                        aria-label={cartQty === 1 ? 'Remove from cart' : 'Decrease quantity'}
                        style={{
                          width: '44px', height: '44px', flexShrink: 0,
                          borderRadius: '50%', border: 'none', cursor: 'pointer',
                          backgroundColor: blushBg, color: maroon,
                          fontFamily: sans, fontSize: '20px', fontWeight: 700, lineHeight: 1,
                        }}
                      >
                        −
                      </button>

                      <span
                        style={{
                          fontFamily: sans, fontSize: '14px', fontWeight: 700,
                          color: maroon, textTransform: 'lowercase', textAlign: 'center',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {cartQty} in cart
                      </span>

                      <button
                        onClick={() => cartQty < MAX_QTY && setQty(cartQty + 1)}
                        disabled={cartQty >= MAX_QTY}
                        aria-label="Increase quantity"
                        style={{
                          width: '44px', height: '44px', flexShrink: 0,
                          borderRadius: '50%', border: 'none',
                          cursor: cartQty >= MAX_QTY ? 'not-allowed' : 'pointer',
                          backgroundColor: maroon, color: 'white',
                          opacity: cartQty >= MAX_QTY ? 0.4 : 1,
                          fontFamily: sans, fontSize: '20px', fontWeight: 700, lineHeight: 1,
                        }}
                      >
                        +
                      </button>
                    </div>
                  )}
                  {/* Why the + stopped working, said plainly. Only when the cap
                      is real stock rather than the arbitrary 10-per-order one. */}
                  {cartQty > 0 && cartQty >= MAX_QTY && MAX_QTY < 10 && (
                    <p role="status" style={{ ...bodyStyle, fontSize: '12.5px', textAlign: 'center', marginTop: '10px', color: '#B3341F', fontWeight: 600 }}>
                      that&apos;s all we have left in {selectedSize}
                    </p>
                  )}
                  {cartQty > 0 && (
                    <Link
                      href="/cart"
                      style={{
                        display: 'block',
                        width: '100%',
                        boxSizing: 'border-box',
                        marginTop: '10px',
                        padding: '14px 28px',
                        textAlign: 'center',
                        border: `1.5px solid ${maroon}`,
                        borderRadius: '100px',
                        color: maroon,
                        fontFamily: sans,
                        fontSize: '15px',
                        fontWeight: 700,
                        textTransform: 'lowercase',
                        textDecoration: 'none',
                      }}
                    >
                      view cart & check out →
                    </Link>
                  )}
                  {buyStatus === 'error' && (
                    <p style={{ ...bodyStyle, color: '#B85C49', textAlign: 'center', marginTop: '12px' }}>
                      something went wrong. please try again.
                    </p>
                  )}

                  {/* Shipping + returns, visible at the decision point instead
                      of collapsed inside the accordion further down the page. */}
                  <div className="pdp-strip pdp-strip--assure">
                    {[
                      // Preorders don't ship in the standing window — the banner above
                      // states their real window instead.
                      {
                        label: FREE_SHIPPING_LABEL,
                        href: '/footer-pages/shipping',
                      },
                      { label: 'easy returns', href: '/footer-pages/returns' },
                      { label: 'free exchanges', href: '/footer-pages/exchanges' },
                    ].map((x, i) => (
                      <Link key={x.label} href={x.href} className="pdp-strip-item">
                        {i > 0 && <span className="pdp-strip-sep">·</span>}
                        <span className="pdp-strip-mark">✦</span>
                        {x.label}
                      </Link>
                    ))}
                  </div>
                </>
              ) : lockedForLaunch ? (
                /* ── Sellable but shop not open yet ── */
                <>
                  <div
                    style={{
                      width: '100%',
                      boxSizing: 'border-box',
                      backgroundColor: 'rgba(169,68,92,0.12)',
                      color: maroon,
                      padding: '16px 28px',
                      fontFamily: sans,
                      fontSize: '15px',
                      fontWeight: 700,
                      textTransform: 'lowercase',
                      borderRadius: '100px',
                      textAlign: 'center',
                    }}
                  >
                    opens friday · 11am pt
                  </div>
                  <p style={{ ...bodyStyle, fontSize: '12px', textAlign: 'center', marginTop: '10px', lineHeight: 1.7 }}>
                    Club members shop 24 hours early.{' '}
                    <Link href="/invite" style={{ color: maroon, fontWeight: 600, textUnderlineOffset: '3px' }}>
                      join the club →
                    </Link>
                  </p>
                </>
              ) : (
                /* ── Not sellable yet (coming soon) ── */
                <>
                  <Link
                    href="/invite"
                    style={{
                      display: 'block',
                      boxSizing: 'border-box',
                      backgroundColor: maroon,
                      color: 'white',
                      padding: '16px 28px',
                      fontFamily: sans,
                      fontSize: '15px',
                      fontWeight: 700,
                      textTransform: 'lowercase',
                      border: 'none',
                      borderRadius: '100px',
                      textAlign: 'center',
                      textDecoration: 'none',
                    }}
                  >
                    join the club for early access
                  </Link>
                  <p style={{ ...bodyStyle, fontSize: '12px', textAlign: 'center', marginTop: '10px', lineHeight: 1.7 }}>
                    Trailblazers get 24-hour early access before anyone else.
                  </p>
                </>
              )}
            </div>

            </div>{/* /.pdp-buybox */}

            {/* ── Everything below the decision ──
                On mobile this renders after the rest of the gallery. */}
            <div className="pdp-details">

            {/* Description */}
            <div style={{ marginBottom: '32px', paddingBottom: '32px', borderBottom: `1px solid ${rule}` }}>
              <p style={bodyStyle}>{product.description}</p>
            </div>

            {/* ── Out in the world ──
                The outdoor shots, deliberately small and deliberately not in
                the gallery above. Up here the studio frames answer "what does
                this garment look like"; down here these answer "what does it
                look like on a trail", which is a different question and a
                worse job for a full-width hero-sized photo.

                A horizontally scrolling row rather than a grid: it stays one
                line tall on a phone, so it never pushes the fit and care
                copy off the screen, and the overflow makes it obvious there
                are more to swipe to. Tapping opens the same lightbox the
                gallery uses. */}
            {lifestyleImages.length > 0 && (
              <div style={{ marginBottom: '32px', paddingBottom: '32px', borderBottom: `1px solid ${rule}` }}>
                <p style={{ ...eyebrowStyle, fontSize: '12px', marginBottom: '12px' }}>
                  out in the world
                </p>
                <div
                  style={{
                    display: 'flex',
                    gap: '8px',
                    overflowX: 'auto',
                    // Lets the row bleed to the screen edge on a phone, so the
                    // last thumbnail is visibly cut off — the cue that says
                    // "scrollable" without needing an arrow.
                    scrollSnapType: 'x proximity',
                    paddingBottom: '4px',
                    WebkitOverflowScrolling: 'touch',
                  }}
                >
                  {lifestyleImages.map((src, i) => (
                    <button
                      key={src}
                      onClick={() => setLifestyleIdx(i)}
                      aria-label={`${product.name} in ${selectedColor} — photo ${i + 1} of ${lifestyleImages.length}, open full screen`}
                      style={{
                        position: 'relative',
                        flex: '0 0 auto',
                        width: '104px',
                        height: '156px',
                        padding: 0,
                        border: `1px solid ${rule}`,
                        borderRadius: '10px',
                        overflow: 'hidden',
                        cursor: 'pointer',
                        background: blushBg,
                        scrollSnapAlign: 'start',
                      }}
                    >
                      <Image
                        src={src}
                        alt=""
                        fill
                        sizes="104px"
                        style={{ objectFit: 'cover' }}
                        // Well below the fold on every viewport, and there are
                        // up to six of them — no reason to compete with the
                        // gallery for bandwidth.
                        loading="lazy"
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Fit & sizing */}
            {fabricDetail?.fit && (
              <div style={{ marginBottom: '32px', paddingBottom: '32px', borderBottom: `1px solid ${rule}` }}>
                <p style={{ ...eyebrowStyle, fontSize: '12px', marginBottom: '12px' }}>fit & sizing</p>
                {Array.isArray(fabricDetail.fit) ? (
                  <ul style={{ ...bodyStyle, margin: 0, padding: '0 0 0 16px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    {fabricDetail.fit.map((point) => <li key={point}>{point}</li>)}
                  </ul>
                ) : (
                  fabricDetail.fit.split('\n\n').map((block, i) => (
                    <p key={i} style={{ ...bodyStyle, margin: i > 0 ? '10px 0 0' : 0 }}>{block}</p>
                  ))
                )}
                {/* Built from the models actually present in the gallery on
                    screen, so it lists both of them on Picnic and cannot drift
                    out of step with the photographs. */}
                {(modelLine ?? fabricDetail.modelNote) && (
                  <p style={{ ...bodyStyle, fontSize: '12.5px', fontStyle: 'italic', marginTop: '12px' }}>
                    {modelLine ?? fabricDetail.modelNote}
                  </p>
                )}
                {fabricDetail.sizeChart && (
                  <p style={{ ...bodyStyle, fontSize: '13px', marginTop: '12px' }}>
                    Full measurements in the <span style={{ color: maroon, fontWeight: 600 }}>size guide</span> below.
                  </p>
                )}
                {/* Insertion B — turns "true to size" from a claim we make
                    into a count of customers, in the exact block where the
                    sizing objection lives. Hidden until enough people have
                    answered the fit question for a percentage to mean
                    anything. */}
                {reviews && <FitConsensus summary={reviews} />}
                <p style={{ ...bodyStyle, marginTop: '16px' }}>
                  Fit question? Email <span style={{ color: maroon, fontWeight: 600 }}>hello@tualmi.com</span>
                </p>
              </div>
            )}

            {/* Accordion */}
            <div>
              {accordionItems.map(({ key, label, content }) => (
                <div key={key} style={{ borderBottom: `1px solid ${rule}` }}>
                  <button
                    onClick={() => toggleSection(key)}
                    style={{
                      width: '100%',
                      padding: '16px 0',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      fontFamily: sans,
                      fontSize: '13px',
                      fontWeight: 700,
                      letterSpacing: '0.06em',
                      textTransform: 'lowercase',
                      color: maroon,
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                    }}
                  >
                    <span>{label}</span>
                    <span style={{ fontSize: '16px', color: soft, fontWeight: 400 }}>{expandedSection === key ? '−' : '+'}</span>
                  </button>
                  {expandedSection === key && (
                    <div style={{ paddingBottom: '16px', ...bodyStyle, lineHeight: 1.9 }}>
                      {content}
                    </div>
                  )}
                </div>
              ))}
            </div>

            </div>{/* /.pdp-details */}

          </div>
        </div>
      </div>

      {lightboxIdx !== null && (
        <ImageLightbox
          images={gallery}
          index={lightboxIdx}
          alt={`${product.name} — ${selectedColor}`}
          onClose={() => setLightboxIdx(null)}
          onIndexChange={setLightboxIdx}
        />
      )}

      {/* Same viewer, its own image set — so paging through the outdoor shots
          doesn't wander into the studio gallery and vice versa. */}
      {lifestyleIdx !== null && (
        <ImageLightbox
          images={lifestyleImages}
          index={lifestyleIdx}
          alt={`${product.name} in ${selectedColor}, outdoors`}
          onClose={() => setLifestyleIdx(null)}
          onIndexChange={setLifestyleIdx}
        />
      )}

      {/* ── Sticky mobile buy bar ──
          Mobile only. On by default; hides only while the inline buy box is on
          screen. There is always a live, priced CTA within thumb reach. */}
      {buyable && (
        <div
          className="pdp-buybar"
          data-visible={showStickyBar ? 'true' : 'false'}
          aria-hidden={!showStickyBar}
        >
          <div className="pdp-buybar-info">
            <span className="pdp-buybar-name">{product.name}</span>
            <span className="pdp-buybar-meta">
              {selectedColor.toLowerCase()}
              {selectedSize ? ` · ${selectedSize}` : ' · pick a size'}
            </span>
          </div>
          {/* Once it's in the cart the bar becomes a link to the cart. It used
              to keep calling handleBuy while reading "in cart", so tapping it
              silently piled on quantity and never went anywhere. */}
          {cartQty > 0 ? (
            <Link href="/cart" className="pdp-buybar-cta">
              view cart ({cartQty}) →
            </Link>
          ) : selectedSoldOut ? (
            /* Tapping this used to add a sold-out size to the cart from
               anywhere on the page, bypassing the size picker entirely. */
            <button onClick={handleBuy} className="pdp-buybar-cta" aria-label={`${selectedSize} ${SOLD_OUT_LABEL} — choose another size`}>
              {SOLD_OUT_LABEL} — pick a size
            </button>
          ) : (
            <button onClick={handleBuy} className="pdp-buybar-cta">
              {isPreorder ? 'preorder' : 'add'} — ${(product.price / 100).toFixed(2)}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
