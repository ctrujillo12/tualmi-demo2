'use client';

import Link from 'next/link';
import { useState } from 'react';
import PhoneOptIn, { PHONE_THEMES } from './PhoneOptIn';
import { getAttribution } from '@/lib/attribution';
import { getReferralCode } from '@/lib/referralClient';
import { WELCOME_CODE, saveWelcomeCode } from '@/lib/discount';

const sans   = 'var(--font-montserrat), system-ui, sans-serif';
const serif  = "'Cormorant Garamond', Georgia, serif";

const LINK_COL_1 = [
  { name: 'start a return/exchange', href: '/footer-pages/exchanges' },
  { name: 'shipping',     href: '/footer-pages/shipping' },
  { name: 'returns',      href: '/footer-pages/returns' },
  { name: 'size & fit',   href: '/footer-pages/size-fit' },
  { name: 'garment care', href: '/footer-pages/garment-care' },
];

const LINK_COL_2 = [
  // The nav follows the hero comp, which has no slot for the story page. Its
  // only other link is in the about section and is hidden below xl, so without
  // this entry /story is unreachable on most screens.
  { name: 'our story',            href: '/story' },
  { name: 'in the wild',          href: '/in-the-wild' },
  // A page, not a mailto:. Google's automated checks crawl pages, so a
  // mailto: href left the site with no discoverable contact information at
  // all -- which is how a new store ends up suspended for Misrepresentation.
  { name: 'contact us',           href: '/footer-pages/contact' },
  { name: 'privacy policy',       href: '/footer-pages/privacy' },
  { name: 'terms and conditions', href: '/footer-pages/legal' },
];

export default function Footer() {
  const [email, setEmail]   = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  // 'phone' = email is already saved, we're just asking for the number.
  const [stage, setStage]   = useState<'phone' | 'done'>('phone');
  const [joinedSms, setJoinedSms] = useState(false);

  const validEmail = email.includes('@');

  async function handleSubmit() {
    if (!validEmail || status === 'loading') return;
    setStatus('loading');
    try {
      const res = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'footer', attribution: getAttribution(), ref: getReferralCode() }),
      });
      setStatus(res.ok ? 'success' : 'error');
      // Same welcome offer as the popup — one club, one code.
      if (res.ok) saveWelcomeCode();
    } catch {
      setStatus('error');
    }
  }

  return (
    <footer
      style={{
        position: 'relative',
        zIndex: 3,
        // Solid brand maroon — matches the landing-page palette and keeps the
        // white type crisp without needing a photo overlay or text shadows.
        backgroundColor: '#A9445C',
        padding: 'clamp(48px, 7vw, 88px) clamp(24px, 6vw, 72px) clamp(28px, 4vw, 44px)',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto', position: 'relative', zIndex: 1 }}>

        {/* ── Top row: links left, signup right ── */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            gap: 'clamp(32px, 5vw, 64px)',
            flexWrap: 'wrap',
            marginBottom: 'clamp(40px, 6vw, 72px)',
          }}
        >
          {/* Link columns */}
          <div style={{ display: 'flex', gap: 'clamp(40px, 6vw, 88px)' }}>
            {[LINK_COL_1, LINK_COL_2].map((col, i) => (
              <ul key={i} style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {col.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      style={{ fontFamily: sans, fontSize: '14px', fontWeight: 500, color: 'rgba(255,255,255,0.92)', textDecoration: 'none', textTransform: 'lowercase' }}
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            ))}
          </div>

          {/* Join the club */}
          <div style={{ maxWidth: '420px', flex: '1 1 320px' }}>
            <h3
              style={{
                fontFamily: sans,
                fontWeight: 700,
                fontSize: 'clamp(24px, 3vw, 32px)',
                letterSpacing: '-0.02em',
                color: '#fff',
                margin: '0 0 14px',
                textTransform: 'lowercase',
              }}
            >
              get 10% off your first order.
            </h3>

            {/* Same three perks as the welcome popup — one consistent ask. */}
            <ul
              style={{
                listStyle: 'none', padding: 0, margin: '0 0 22px',
                display: 'flex', flexDirection: 'column', gap: '9px',
              }}
            >
              {[
                '10% off, the second you join',
                'special perks, discounts + early access to new drops',
                'insider info and behind-the-scenes sneak peeks',
              ].map((perk) => (
                <li
                  key={perk}
                  style={{
                    display: 'flex', alignItems: 'flex-start', gap: '10px',
                    fontFamily: sans, fontSize: '14px', fontWeight: 500,
                    color: 'rgba(255,255,255,0.9)', lineHeight: 1.6,
                  }}
                >
                  <span style={{ color: '#fff', flexShrink: 0 }}>✦</span>
                  {perk}
                </li>
              ))}
            </ul>

            {status === 'success' && stage === 'phone' ? (
              <PhoneOptIn
                email={email}
                source="footer"
                theme={PHONE_THEMES.dark}
                onDone={({ joinedSms: j }) => { setJoinedSms(j); setStage('done'); }}
              />
            ) : status === 'success' ? (
              <p style={{ fontFamily: sans, fontSize: '13px', fontWeight: 600, color: '#fff', margin: 0, textTransform: 'lowercase' }}>
                you’re in ✦ here’s 10% off your first order:{' '}
                <span style={{ letterSpacing: '0.1em' }}>{WELCOME_CODE}</span>
                {joinedSms ? ' — and we’ll text you when the next piece drops.' : ' — it’s in your inbox too.'}
              </p>
            ) : (
              <>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    border: '1.5px solid rgba(255,255,255,0.85)',
                    borderRadius: '100px',
                    overflow: 'hidden',
                    backgroundColor: 'rgba(255,255,255,0.08)',
                  }}
                >
                  <input
                    type="email"
                    placeholder="your email"
                    className="footer-email-input"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                    style={{
                      flex: 1,
                      padding: '12px 22px',
                      border: 'none',
                      outline: 'none',
                      background: 'transparent',
                      fontFamily: sans,
                      fontSize: '14px',
                      fontWeight: 500,
                      color: '#fff',
                    }}
                  />
                  <button
                    onClick={handleSubmit}
                    disabled={!validEmail}
                    style={{
                      padding: '12px 26px',
                      background: 'none',
                      border: 'none',
                      fontFamily: sans,
                      fontSize: '14px',
                      fontWeight: 700,
                      color: '#fff',
                      cursor: validEmail ? 'pointer' : 'default',
                      opacity: validEmail ? 1 : 0.5,
                      textTransform: 'lowercase',
                    }}
                  >
                    {status === 'loading' ? '…' : 'join'}
                  </button>
                </div>
                {status === 'error' && (
                  <p style={{ fontFamily: sans, fontSize: '12px', color: '#FFD8CE', margin: '10px 0 0' }}>
                    something went wrong — please try again.
                  </p>
                )}
              </>
            )}
          </div>
        </div>

        {/* ── Big centered logo ── */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 'clamp(10px, 1.5vw, 20px)', marginBottom: '14px' }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images-2/logo2-maroon.png"
            alt=""
            style={{ height: 'clamp(64px, 9vw, 120px)', width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }}
          />
          <span
            style={{
              fontFamily: serif,
              fontSize: 'clamp(56px, 9vw, 110px)',
              fontWeight: 400,
              color: '#fff',
              lineHeight: 1,
            }}
          >
            Tualmi
          </span>
        </div>

        {/* ── Bottom line ── */}
        <p style={{ fontFamily: sans, fontSize: '12px', fontWeight: 500, color: 'rgba(255,255,255,0.85)', textAlign: 'center', margin: 0, textTransform: 'lowercase' }}>
          @ 2026, tualmi
        </p>
      </div>
    </footer>
  );
}
