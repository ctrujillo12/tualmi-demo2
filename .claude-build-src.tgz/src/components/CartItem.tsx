'use client';

import Image from 'next/image';
import Link from 'next/link';
import { CartItem as CartItemType } from '@/types';
import { useCartStore } from '@/store/cartStore';
import { galleryImageFor } from '@/lib/productColors';
import { availability } from '@/lib/inventory';
import { SOLD_OUT_LABEL } from '@/lib/lowStock';
import { hasDetailPage } from '@/lib/catalog';

interface CartItemProps {
  item: CartItemType;
}

// Landing-page design tokens
const sans   = 'var(--font-montserrat), system-ui, sans-serif';
const maroon = '#A9445C';
const soft   = '#C9849A';
const rule   = '#F0D9E1';

export default function CartItem({ item }: CartItemProps) {
  const { updateQuantity, removeItem } = useCartStore();

  const handleQuantityChange = (newQuantity: number) => {
    updateQuantity(item.product.id, item.selectedSize, item.selectedColor, newQuantity);
  };

  const handleRemove = () => {
    removeItem(item.product.id, item.selectedSize, item.selectedColor);
  };

  /**
   * Live availability of this exact line. The cart re-syncs variants from
   * Shopify on load (cartStore.refreshFromShopify), so this reflects stock as
   * of this page view rather than whenever the item was added.
   */
  const lineState = availability(item.product, item.selectedColor, item.selectedSize);

  /**
   * First usable image: what was saved with the cart line, else the live
   * gallery for that colourway, else nothing (and we render a text tile).
   * Empty strings are filtered out — next/image renders a blank box for those
   * rather than failing loudly.
   */
  const handle = item.product.handle ?? item.product.id;

  // Only products with a real page get linked. The tote is buyable but has no
  // detail page, so linking it sent a shopper who tapped her own cart item
  // straight to the homepage. CartUpsell already guards this; this didn't.
  const productUrl = hasDetailPage(handle) ? `/products/${handle}` : null;

  // The snapshot first — it is written by the add paths and rewritten by
  // refreshFromShopify(), both of which are now colour-scoped. The fallback is
  // the gallery for THIS colourway, never `images[1]`, which was just "the
  // product's second photo" and had no relationship to the chosen colour.
  //
  // Carts persist in localStorage, so lines added before this fix can still
  // hold a wrong-colourway URL. refreshFromShopify() runs on every cart load
  // and overwrites it, so those repair themselves on the next visit.
  const thumb = [
    item.product.images?.[0],
    galleryImageFor(handle, item.selectedColor),
  ].find((src): src is string => typeof src === 'string' && src.trim().length > 0);

  return (
    <div className="cart-line" style={{ display: 'flex', gap: '20px', paddingBottom: '28px', marginBottom: '28px', borderBottom: `1px solid ${rule}` }}>

      {/* Product image.
          The cart stores whatever image was current when the item was added, so
          the entry can be missing (empty array), stale, or point at a file that
          no longer exists — which rendered as a blank white box next to a $146
          total. Fall back through the live gallery, then to a branded tile, so
          this can never be empty again. */}
      {(() => {
        const thumbStyle: React.CSSProperties = { position: 'relative', width: '100px', height: '130px', flexShrink: 0, backgroundColor: '#FBF1F5', display: 'block', borderRadius: '8px', overflow: 'hidden' };
        const inner = thumb ? (
          <Image
            src={thumb}
            alt={item.product.name}
            fill
            sizes="(max-width: 640px) 80px, 100px"
            style={{ objectFit: 'cover' }}
          />
        ) : (
          <span
            style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: sans, fontSize: '11px', fontWeight: 700,
              color: maroon, textTransform: 'lowercase', textAlign: 'center',
              padding: '8px', lineHeight: 1.3,
            }}
          >
            {item.product.name}
          </span>
        );
        return productUrl ? (
          <Link href={productUrl} className="cart-line-thumb" style={thumbStyle}>{inner}</Link>
        ) : (
          <div className="cart-line-thumb" style={thumbStyle}>{inner}</div>
        );
      })()}

      {/* Details */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px' }}>
          <div>
            {(() => {
              const nameStyle: React.CSSProperties = { fontFamily: sans, fontSize: '16px', fontWeight: 700, letterSpacing: '-0.01em', color: maroon, textDecoration: 'none', display: 'block', marginBottom: '6px', textTransform: 'lowercase' };
              return productUrl ? (
                <Link href={productUrl} style={nameStyle}>{item.product.name}</Link>
              ) : (
                <span style={nameStyle}>{item.product.name}</span>
              );
            })()}
            <p style={{ fontFamily: sans, fontSize: '12px', fontWeight: 500, color: soft, margin: '0 0 2px' }}>
              Size: {item.selectedSize}
            </p>
            <p style={{ fontFamily: sans, fontSize: '12px', fontWeight: 500, color: soft, margin: 0 }}>
              Color: {item.selectedColor}
            </p>
            {/* Was "pre-order · {window}", gated on item.isPreorder. The word
                is gone from the site; the date is the part a shopper needed
                anyway, and it now shows for any line that carries one. The
                old fallback ("ships when collection drops") is gone too — a
                line with no window shows nothing rather than a vague phrase. */}
            {item.shippingWindow && (
              <p style={{ fontFamily: sans, fontSize: '11px', fontWeight: 700, color: soft, marginTop: '8px', textTransform: 'lowercase', letterSpacing: '0.08em' }}>
                {item.shippingWindow}
              </p>
            )}
            {/* Flagged on the line itself, right next to the remove button that
                resolves it — not only in a summary further down the page. */}
            {lineState.status === 'sold-out' && (
              <p role="status" style={{ fontFamily: sans, fontSize: '11.5px', fontWeight: 700, color: '#B85C49', marginTop: '8px', textTransform: 'lowercase', letterSpacing: '0.06em' }}>
                {SOLD_OUT_LABEL} — please remove
              </p>
            )}
            {lineState.status === 'available' &&
              lineState.quantity !== null &&
              lineState.quantity < item.quantity && (
              <p role="status" style={{ fontFamily: sans, fontSize: '11.5px', fontWeight: 700, color: '#B85C49', marginTop: '8px', textTransform: 'lowercase', letterSpacing: '0.06em' }}>
                only {lineState.quantity} left — quantity will be reduced at checkout
              </p>
            )}
          </div>
          <p className="cart-line-price" style={{ fontFamily: sans, fontSize: '14px', fontWeight: 600, color: maroon, whiteSpace: 'nowrap', margin: 0 }}>
            ${((item.product.price * item.quantity) / 100).toFixed(2)}
          </p>
        </div>

        {/* Qty + Remove */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', border: `1.5px solid ${rule}`, borderRadius: '100px', overflow: 'hidden' }}>
            <button
              onClick={() => handleQuantityChange(item.quantity - 1)}
              style={{ width: '30px', height: '30px', border: 'none', background: 'none', color: maroon, fontFamily: sans, fontSize: '15px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            >
              −
            </button>
            <span style={{ width: '28px', textAlign: 'center', fontFamily: sans, fontSize: '13px', fontWeight: 600, color: maroon }}>
              {item.quantity}
            </span>
            <button
              onClick={() => handleQuantityChange(item.quantity + 1)}
              style={{ width: '30px', height: '30px', border: 'none', background: 'none', color: maroon, fontFamily: sans, fontSize: '15px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            >
              +
            </button>
          </div>
          <button
            onClick={handleRemove}
            style={{ fontFamily: sans, fontSize: '12px', fontWeight: 600, color: soft, background: 'none', border: 'none', cursor: 'pointer', textTransform: 'lowercase', textDecoration: 'underline', textUnderlineOffset: '3px' }}
          >
            remove
          </button>
        </div>

      </div>
    </div>
  );
}
